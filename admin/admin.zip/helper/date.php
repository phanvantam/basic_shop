<?php

function format_date($time){
    return date(' H:i - d/m/Y ' ,$time) ;
}