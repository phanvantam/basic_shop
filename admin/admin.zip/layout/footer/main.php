<div id="footer-wp">
    <div class="wp-inner">
        <p id="copyright">2016 © AdminV1 Theme by Hocweb123.edu.vn</p>
    </div>
</div>
</div>
</div>
</body>
</html>